import React from "react";

const AdminDashboard = () => (
  <div>
    <h2>Admin Dashboard</h2>
    <p>Manage users, service providers, and bookings here.</p>
    {/* TODO: Add admin features */}
  </div>
);

export default AdminDashboard;
